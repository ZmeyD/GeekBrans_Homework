﻿using System;

namespace Sixth
{
    class MainClass
    {
      
            // Козлов Никита Сергеевич
            //Создать класс с методами, которые могут пригодиться в вашей учебе (Print, Pause).
            
      
        

    }
}
